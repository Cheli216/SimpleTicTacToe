package finalProject;
/* Author: Tao Vue & Michelle Cappellin 
 * Class 1082 - Tuesday
 * Instructor - Zak Banni
 * Due Date: May 7th , 2020
 * FINAL PROJECT PROGRAMMING
 * **/

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class TicTacToeGame extends JFrame implements ActionListener {

private char[][] symbols; // X AND O SYMBOLS
private JPanel board; // BOARD LAYOUT
private JLabel announcement; // DISPLAY MESSAGES TO THE NORTH BORDER LAYOUT
private JButton[][] buttons; // 2DIMENSIOARRAY BUTTONS THAT PLAYERS CLICK ON
private boolean turnX; // BOOLEAN TO TAKE TURNS AFTER A PLAYER CLICKS ON THEIR BOX
private static ArrayList<Users> user = new ArrayList<Users>();
private static String fName;
private static String fName2;
private static int score = 0;
private static Users player1 = new Users(fName, score);
private static Users player2 = new Users(fName2, score);
private static TrackingFile p1TF = new TrackingFile();// = new TrackingFile();


public TicTacToeGame() {

	super("Tic-Tac-Toe Game");// SUPER IMPLEMENTED TO TIE EVERYTHING TOGETHER 
								// GAME NAME shows on top of the gameboard

	this.setLayout(new BorderLayout());
	this.setSize(900, 900);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	JOptionPane.showMessageDialog(null, " --WELCOME TO THE TIC TAC TOE GAME-- "); // SHOWS BEGINNING POP UP MESSAGE
	fName = JOptionPane.showInputDialog(null, " PLAYER 1 FIRST NAME \n", fName, JOptionPane.OK_CANCEL_OPTION); // allows FIRST NAME to be added
	player1.setFirstName(fName);
	player1.setScore(0);
	user.add(player1); // Adding player1 info 
	p1TF.addUser(player1);
	
	
	
	fName2 = JOptionPane.showInputDialog(null, " PLAYER 2 FIRST NAME \n", fName2, JOptionPane.OK_CANCEL_OPTION); // allows FIRST NAME to be added
	player2.setFirstName(fName2);
	player2.setScore(0);
	user.add(player2); // Adding player2 info
	p1TF.addUser(player2);
	p1TF.saveUserFile();

	announcement = new JLabel(" Final Program Project - Tic Tac Toe Game " + "  |||| PLAYER 1: "
			+ player1.toString() + " |||| "+  " PLAYER 2: " + player2.toString() + " |||| PLAYER 1 STARTS THE GAME! ||||"); // BEGINNING HEADER MESSAGE

	announcement.setVisible(true); // SET TO TRUE TO BE ABLE TO LET THE PLAYER VIEW THE ANNOUCEMENT.
	this.add(announcement, BorderLayout.NORTH);// DISPLAYS ON NORTH BORDER AS STATED IN THE PROJECT DETAIL.
	
	board = new JPanel(new GridLayout(3, 3)); // 3x3 GRIDLAYOUT FOR THE BOARD GAME. TOTAL OF 9 BOXES
	board.setVisible(true);
	buttons = new JButton[3][3]; // ARRAYS TO SET FOR 3x3 BOX LAYOUT
	symbols = new char[3][3]; // CHAR SETTING OF X'S AND O'S AFTER CLICKING ON THE BOX.
	for (int i = 0; i < 3; i++) { // FOR LOOP TO LINK BUTTONS, EMPTY BOX, AND APPROPRIATE X AND O SYMBOL
									// DISPLAYS.
		for (int j = 0; j < 3; j++) {
			buttons[i][j] = new JButton(" ");
			buttons[i][j].setEnabled(true);
			buttons[i][j].addActionListener(this);
			buttons[i][j].setActionCommand(i + " " + j);
			buttons[i][j].setVisible(true);
			board.add(buttons[i][j]);
			symbols[i][j] = '.';

		}
		this.add(board, BorderLayout.CENTER); // A CENTER BORDER LAYOUT AS DESCRIBED IN PROGRAMMING DETAILED.
		turnX = true;
	}
}


private boolean won(char playerMark, char[][] board) { // BOOLEAN TO KEEP TRACK OF 3 IN A ROW TO DISPLAY WINNER.
	for (int row = 0; row < 3; row++) {
		int count = 0;
		for (int col = 0; col < 3; col++) {
			if (board[row][col] == playerMark)
				count++;
			else
				count = 0;
		}

		if (count == 3)
			return true;
	}

	for (int col = 0; col < 3; col++) {
		int count = 0;
		for (int row = 0; row < 3; row++) {
			if (board[row][col] == playerMark)
				count++;
			else
				count = 0;
		}

		if (count == 3)
			return true;
	}
	if (board[1][1] == playerMark && board[0][0] == playerMark && board[2][2] == playerMark)
		return true;

	if (board[1][1] == playerMark && board[0][2] == playerMark && board[2][0] == playerMark)
		return true;
	return false;
}

private boolean tie(char[][] board) { // BOOLEAN TO KEEP TRACK IF THERE ARE NO 3 MATCHING SYMBOLS AND DISPLAYS A TIE
										// GAME.

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (board[i][j] == '.')
				return false;
		}
	}

	return true;
}

public void actionPerformed(ActionEvent e) { // ACTION PERFORMED METHOD

	String a = e.getActionCommand();
	if (a.length() == 3) {

		Scanner input = new Scanner(a);
		String rowString = input.next();
		String colString = input.next();

		int row = Integer.parseInt(rowString);
		int col = Integer.parseInt(colString);

		JButton button = buttons[row][col];

		if (button.isEnabled()) {
			if (turnX) {// DISPLAY TO SHOW
				announcement.setText("**** IT IS " + player1.getFirstName() + "'S TURN!!! ****"); // PLAYER'S O TURN TO CLICK ON AN EMPTY BOX
																								 
			
																								
				button.setText("X");
				button.setBackground(Color.WHITE);
				symbols[row][col] = 'X';
				button.setFont(button.getFont().deriveFont(100.0f)); // INCREASING THE SIZE OF THE CHAR
				button.setEnabled(false);
				turnX = false;
			} else {
				announcement.setText("**** IT IS " + player2.getFirstName() + "'S TURN!!! ****"); // DISPLAY TO SHOW
				// PLAYER'S X TURN TO
				// CLICK ON AN EMPTY BOX
				button.setText("O");
				button.setBackground(Color.WHITE);
				symbols[row][col] = 'O';
				button.setFont(button.getFont().deriveFont(100.0f)); // INCREASING THE SIZE OF THE CHAR
				button.setEnabled(false);
				turnX = true;
			}
		}
		if (tie(symbols)) { // DISPLAYS IF NOBODY GETS THE SAME SYMBOLS FOR 3 IN A ROW
			announcement.setText("  **** PLAYER 1: "
					+ player1.toString() + "  PLAYER 2: " + player2.toString() + ". ");
			for (int i = 0; i < 3; i++)
				for (int j = 0; j < 3; j++)
					buttons[i][j].setEnabled(false);
			JOptionPane.showMessageDialog(null, "The game was tie!");// SHOWS POP UP MESSAGE
			int answer = JOptionPane.showConfirmDialog(null, "", "Do you want to start a new game",
					JOptionPane.YES_NO_OPTION);// OPTION TO CHOOSE
			if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window
				this.clearIt(e);
			} else if (answer == JOptionPane.NO_OPTION) { // if no it will end the program
				System.exit(0);
			}
		}
		if (won('X', symbols)) { // DISPLAY IF X HAS 3 SAME SYMBOLS IN A ROW
			announcement.setText("  **** PLAYER 1: "
					+ player1.toString() + "  PLAYER 2: " + player2.toString() + ". ");
			int player1CurrentScore = player1.getScore();
			player1.setScore(player1CurrentScore = player1CurrentScore + 1);
			
			
			for (int i = 0; i < 3; i++)
				for (int j = 0; j < 3; j++)
					buttons[i][j].setEnabled(false);
			JOptionPane.showMessageDialog(null, "PLAYER1: " + player1.getFirstName() + " WINS!");// SHOWS POP UP MESSAGE
			int answer = JOptionPane.showConfirmDialog(null, "Do you want to start a new game?\n", "",
					JOptionPane.YES_NO_OPTION);// OPTION TO CHOOSE

			if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window

				this.clearIt(e);
			} else if (answer == JOptionPane.NO_OPTION) { // if no it will end the program
				System.exit(0);
			}

		}

		if (won('O', symbols)) { // DISPLAY IF O HAS 3 SAME SYMBOLS IN A ROW
			announcement.setText("  **** PLAYER 1: "
					+ player1.toString() + "  PLAYER 2: " + player2.toString() + ". ");
			int player2CurrentScore = player2.getScore();
			player2.setScore(player2CurrentScore = player2CurrentScore+1);
			
			for (int i = 0; i < 3; i++)
				for (int j = 0; j < 3; j++)
					buttons[i][j].setEnabled(false);
			JOptionPane.showMessageDialog(null, "PLAYER2: " + player2.getFirstName() + " WINS!"); // SHOWS POP UP MESSAGE
			int answer = JOptionPane.showConfirmDialog(null, "Do you want to start a new game?\n", "",
					JOptionPane.YES_NO_OPTION); // OPTION TO CHOOSE

			if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window
				this.clearIt(e);
			} else if (answer == JOptionPane.NO_OPTION) { // if no it will end the program
				System.exit(0);
			}

		}
		input.close(); // CLOSING THE STREAM INPUT

	}
}

public void clearIt(ActionEvent e) {

	for (int i = 0; i < 3; i++) {

		for (int j = 0; j < 3; j++)
			symbols[i][j] = ('.');

	}
	for (int i = 0; i < 3; i++) {

		for (int j = 0; j < 3; j++)
			buttons[i][j].setText(" ");

	}

	for (int i = 0; i < 3; i++) {

		for (int j = 0; j < 3; j++)
			buttons[i][j].setEnabled(true);
	}
	turnX = true;

}
//import java.util.ArrayList;
//import java.util.Scanner;
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JOptionPane;
//import javax.swing.JPanel;
//import javax.swing.JTextArea;
//
//import java.awt.BorderLayout;
//import java.awt.Color;
//import java.awt.Font;
//import java.awt.GridLayout;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//public class TicTacToeGame extends JFrame implements ActionListener {
//
//	private char[][] symbols; // X AND O SYMBOLS
//	private JPanel board; // BOARD LAYOUT
//	private JLabel announcement; // DISPLAY MESSAGES TO THE NORTH BORDER LAYOUT
//	private JButton[][] buttons; // 2DIMENSIOARRAY BUTTONS THAT PLAYERS CLICK ON
//	private boolean turnX; // BOOLEAN TO TAKE TURNS AFTER A PLAYER CLICKS ON THEIR BOX
//	private static ArrayList<Users> user = new ArrayList<Users>();
////	private static String fName, lName = null;
////	private static int score = 0;
//	private static String fName;
//	private static String fName2;
//	private static int score = 0;
//	Users player1 = new Users(fName, score);
//	Users player2 = new Users(fName2, score);
//	TrackingFile p1TF;// = new TrackingFile()
//	private static Stats scoreBoard = new Stats(null);
//
//	public TicTacToeGame() {
//
//		super("Tic-Tac-Toe Game");// SUPER IMPLEMENTED TO TIE EVERYTHING TOGETHER // GAME NAME shows on top of the
//									// gameboard
//
//		this.setLayout(new BorderLayout());
//		this.setSize(900, 900);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
//		JOptionPane.showMessageDialog(null, " --WELCOME TO THE TIC TAC TOE GAME-- "); // SHOWS BEGINNING POP UP MESSAGE
//		JOptionPane.showMessageDialog(null, " Enter Player1 Information\n"); // adding first player info
//		fName = JOptionPane.showInputDialog(null, " PLAYER 1 FIRST NAME \n", fName, JOptionPane.OK_CANCEL_OPTION); // allows FIRST NAME to be added
////		lName = JOptionPane.showInputDialog(null, " PLAYER 1 LAST NAME \n", lName, JOptionPane.OK_CANCEL_OPTION); // allows second name to ne added
//		Users player1 = new Users(fName, lName, score);
//		user.add(player1); // Adding player1 info
//
//		
//		int answer = JOptionPane.showConfirmDialog(null, "", " Will there be Player2?\n", JOptionPane.YES_NO_OPTION);// OPTION
//																														// TO
//																														// CHOOSE
//		if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window
//			JOptionPane.showMessageDialog(null, " Enter Player2 Information\n"); // adding second player info
//			fName = JOptionPane.showInputDialog(null, " PLAYER 2 FIRST NAME \n", fName, JOptionPane.OK_CANCEL_OPTION); // allows FIRST NAME to be added
//			lName = JOptionPane.showInputDialog(null, " PLAYER 2 LAST NAME \n", lName, JOptionPane.OK_CANCEL_OPTION); // allows second name to ne added
//			Users player2 = new Users(fName, lName, score);
//			user.add(player2); // Adding input users informations
//			
//			announcement = new JLabel(" Final Program Project - Tic Tac Toe Game " + "  **** PLAYER 1: "
//					+ player1.toString() + "  PLAYER 2: " + player2.toString() + "PLAYER 1 STARTS THE GAME FIRST!!!! ****"); // BEGINNING HEADER MESSAGE
//
//			announcement.setVisible(true); // SET TO TRUE TO BE ABLE TO LET THE PLAYER VIEW THE ANNOUCEMENT.
//			this.add(announcement, BorderLayout.NORTH);// DISPLAYS ON NORTH BORDER AS STATED IN THE PROJECT DETAIL.
//
//			board = new JPanel(new GridLayout(3, 3)); // 3x3 GRIDLAYOUT FOR THE BOARD GAME. TOTAL OF 9 BOXES
//			board.setVisible(true);
//			buttons = new JButton[3][3]; // ARRAYS TO SET FOR 3x3 BOX LAYOUT
//			symbols = new char[3][3]; // CHAR SETTING OF X'S AND O'S AFTER CLICKING ON THE BOX.
//			for (int i = 0; i < 3; i++) { // FOR LOOP TO LINK BUTTONS, EMPTY BOX, AND APPROPRIATE X AND O SYMBOL
//											// DISPLAYS.
//				for (int j = 0; j < 3; j++) {
//					buttons[i][j] = new JButton(" ");
//					buttons[i][j].setEnabled(true);
//					buttons[i][j].addActionListener(this);
//					buttons[i][j].setActionCommand(i + " " + j);
//					buttons[i][j].setVisible(true);
//					board.add(buttons[i][j]);
//					symbols[i][j] = '.';
//
//				}
//				this.add(board, BorderLayout.CENTER); // A CENTER BORDER LAYOUT AS DESCRIBED IN PROGRAMMING DETAILED.
//				turnX = true;
//			}
//			
//		}
//			else if (answer == JOptionPane.NO_OPTION)
//
//		{
//
//			announcement = new JLabel(" Final Program Project - Tic Tac Toe Game " + "  **** PLAYER 1: "
//					+ player1.toString() + " STARTS THE GAME FIRST!!!! ****"); // BEGINNING HEADER MESSAGE
//
//			announcement.setVisible(true); // SET TO TRUE TO BE ABLE TO LET THE PLAYER VIEW THE ANNOUCEMENT.
//			this.add(announcement, BorderLayout.NORTH);// DISPLAYS ON NORTH BORDER AS STATED IN THE PROJECT DETAIL.
//
//			board = new JPanel(new GridLayout(3, 3)); // 3x3 GRIDLAYOUT FOR THE BOARD GAME. TOTAL OF 9 BOXES
//			board.setVisible(true);
//			buttons = new JButton[3][3]; // ARRAYS TO SET FOR 3x3 BOX LAYOUT
//			symbols = new char[3][3]; // CHAR SETTING OF X'S AND O'S AFTER CLICKING ON THE BOX.
//			for (int i = 0; i < 3; i++) { // FOR LOOP TO LINK BUTTONS, EMPTY BOX, AND APPROPRIATE X AND O SYMBOL
//											// DISPLAYS.
//				for (int j = 0; j < 3; j++) {
//					buttons[i][j] = new JButton(" ");
//					buttons[i][j].setEnabled(true);
//					buttons[i][j].addActionListener(this);
//					buttons[i][j].setActionCommand(i + " " + j);
//					buttons[i][j].setVisible(true);
//					board.add(buttons[i][j]);
//					symbols[i][j] = '.';
//
//				}
//				this.add(board, BorderLayout.CENTER); // A CENTER BORDER LAYOUT AS DESCRIBED IN PROGRAMMING DETAILED.
//				turnX = true;
//			}
//		}else if (answer == JOptionPane.CANCEL_OPTION) {
//			System.exit(0);
//		}
//	}
//
//	private boolean won(char playerMark, char[][] board) { // BOOLEAN TO KEEP TRACK OF 3 IN A ROW TO DISPLAY WINNER.
//		for (int row = 0; row < 3; row++) {
//			int count = 0;
//			for (int col = 0; col < 3; col++) {
//				if (board[row][col] == playerMark)
//					count++;
//				else
//					count = 0;
//			}
//
//			if (count == 3)
//				return true;
//		}
//
//		for (int col = 0; col < 3; col++) {
//			int count = 0;
//			for (int row = 0; row < 3; row++) {
//				if (board[row][col] == playerMark)
//					count++;
//				else
//					count = 0;
//			}
//
//			if (count == 3)
//				return true;
//		}
//		if (board[1][1] == playerMark && board[0][0] == playerMark && board[2][2] == playerMark)
//			return true;
//
//		if (board[1][1] == playerMark && board[0][2] == playerMark && board[2][0] == playerMark)
//			return true;
//		return false;
//	}
//
//	private boolean tie(char[][] board) { // BOOLEAN TO KEEP TRACK IF THERE ARE NO 3 MATCHING SYMBOLS AND DISPLAYS A TIE
//											// GAME.
//
//		for (int i = 0; i < 3; i++) {
//			for (int j = 0; j < 3; j++) {
//				if (board[i][j] == '.')
//					return false;
//			}
//		}
//
//		return true;
//	}
//
//	public void actionPerformed(ActionEvent e) { // ACTION PERFORMED METHOD
//
//		String a = e.getActionCommand();
//		if (a.length() == 3) {
//
//			Scanner input = new Scanner(a);
//			String rowString = input.next();
//			String colString = input.next();
//
//			int row = Integer.parseInt(rowString);
//			int col = Integer.parseInt(colString);
//
//			JButton button = buttons[row][col];
//
//			if (button.isEnabled()) {
//				if (turnX) {// DISPLAY TO SHOW
//					announcement.setText("**** IT IS PLAYER O'S TURN!!! ****"); // PLAYER'S O TURN TO CLICK ON AN EMPTY BOX
//																									 
//				
//																									
//					button.setText("X");
//					button.setBackground(Color.WHITE);
//					symbols[row][col] = 'X';
//					button.setFont(button.getFont().deriveFont(100.0f)); // INCREASING THE SIZE OF THE CHAR
//					button.setEnabled(false);
//					turnX = false;
//				} else {
//					announcement.setText("**** IT IS PLAYER X's  TURN!!! ****"); // DISPLAY TO SHOW
//					// PLAYER'S X TURN TO
//					// CLICK ON AN EMPTY BOX
//					button.setText("O");
//					button.setBackground(Color.WHITE);
//					symbols[row][col] = 'O';
//					button.setFont(button.getFont().deriveFont(100.0f)); // INCREASING THE SIZE OF THE CHAR
//					button.setEnabled(false);
//					turnX = true;
//				}
//			}
//			if (tie(symbols)) { // DISPLAYS IF NOBODY GETS THE SAME SYMBOLS FOR 3 IN A ROW
//				announcement.setText("****  --WELCOME TO THE TIC TAC TOE GAME--  ****");
//				for (int i = 0; i < 3; i++)
//					for (int j = 0; j < 3; j++)
//						buttons[i][j].setEnabled(false);
//				JOptionPane.showMessageDialog(null, "The game was tie!");// SHOWS POP UP MESSAGE
//				int answer = JOptionPane.showConfirmDialog(null, "", "Do you want to start a new game",
//						JOptionPane.YES_NO_OPTION);// OPTION TO CHOOSE
//				if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window
//					this.clearIt(e);
//				} else if (answer == JOptionPane.NO_OPTION) { // if no it will end the program
//					System.exit(0);
//				}
//			}
//			if (won('X', symbols)) { // DISPLAY IF X HAS 3 SAME SYMBOLS IN A ROW
//				announcement.setText("****   --WELCOME TO THE TIC TAC TOE GAME--  ****");
//				for (int i = 0; i < 3; i++)
//					for (int j = 0; j < 3; j++)
//						buttons[i][j].setEnabled(false);
//				JOptionPane.showMessageDialog(null, "PLAYER1: " + " X " + " WINS!");// SHOWS POP UP MESSAGE
//				int answer = JOptionPane.showConfirmDialog(null, "Do you want to start a new game?\n", "",
//						JOptionPane.YES_NO_OPTION);// OPTION TO CHOOSE
//
//				if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window
//
//					this.clearIt(e);
//				} else if (answer == JOptionPane.NO_OPTION) { // if no it will end the program
//					System.exit(0);
//				}
//
//			}
//
//			if (won('O', symbols)) { // DISPLAY IF O HAS 3 SAME SYMBOLS IN A ROW
//				announcement.setText("****  --WELCOME TO THE TIC TAC TOE GAME--  ****");
//				for (int i = 0; i < 3; i++)
//					for (int j = 0; j < 3; j++)
//						buttons[i][j].setEnabled(false);
//				JOptionPane.showMessageDialog(null, "PLAYER2: " + " O " + " WINS!"); // SHOWS POP UP MESSAGE
//				int answer = JOptionPane.showConfirmDialog(null, "Do you want to start a new game?\n", "",
//						JOptionPane.YES_NO_OPTION); // OPTION TO CHOOSE
//
//				if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window
//					this.clearIt(e);
//				} else if (answer == JOptionPane.NO_OPTION) { // if no it will end the program
//					System.exit(0);
//				}
//
//			}
//			input.close(); // CLOSING THE STREAM INPUT
//
//		}
//	}
//
//	public void clearIt(ActionEvent e) {
//
//		for (int i = 0; i < 3; i++) {
//
//			for (int j = 0; j < 3; j++)
//				symbols[i][j] = ('.');
//
//		}
//		for (int i = 0; i < 3; i++) {
//
//			for (int j = 0; j < 3; j++)
//				buttons[i][j].setText(" ");
//
//		}
//
//		for (int i = 0; i < 3; i++) {
//
//			for (int j = 0; j < 3; j++)
//				buttons[i][j].setEnabled(true);
//		}
//		turnX = true;
//
//	}

//private void displayBoard() {
//		
//		//Retrieve the board from the game
//		cellBoard = game.getBoard();
//		
//		//Change the icon to correspond with the cell value
//		for(int row = 0; row < ROWS; row++)
//			for(int col = 0; col < COLS; col++) {
//				if(cellBoard[row][col] == Cell.O)
//					board[row][col].setIcon(oIcon);
//				
//				if(cellBoard[row][col] == Cell.X)
//					board[row][col].setIcon(xIcon);
//				
//				if(cellBoard[row][col] == Cell.EMPTY)
//					board[row][col].setIcon(emptyIcon);
//			}
//	}

//	public void startIt(ActionEvent ) {
//
//		int answer = JOptionPane.showConfirmDialog(null, " Are you a new player?\n", "", JOptionPane.YES_NO_OPTION);
//
//		if (answer == JOptionPane.YES_OPTION) { // if yes it will reload the whole game into a new window
//
//			TicTacToeGame ticTac = new TicTacToeGame();
//			ticTac.setVisible(false);
//
//		}
//		if (answer == JOptionPane.CANCEL_OPTION) { // if chosen it will end the program
//			JOptionPane.showMessageDialog(null, "You have exited the program");
//			System.exit(0);
//		}
//
//		if (answer == JOptionPane.NO_OPTION) {
//			this.clearIt(e);
//
//		}
//	}

}

// Generate a random computer move
//    public static int computer_move(int[][] board) {
//	int move = (int)(Math.random()*9);
//
//	while(board[move/3][move%3] != EMPTY) 
//	    move = (int)(Math.random()*9);
//
//	return move;
//    }
//    
//    public static char printChar(int b) {
//    	switch(b) {
//    	case EMPTY:
//    	    return ' ';
//    	case USER:
//    	    return 'X';
//    	case COMPUTER:
//    	    return 'O';
//    	}
//    	return ' ';
//        }
//	
//}
