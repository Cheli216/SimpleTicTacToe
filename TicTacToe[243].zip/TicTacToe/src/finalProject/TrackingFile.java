package finalProject;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class TrackingFile {
	private static ArrayList<Users> userList = new ArrayList<Users>();
	String currentDirectoryLocation = System.getProperty("user.dir");
	File currentDirectory = new File("tttfile.csv");
	private Scanner userAccessFile;
	private FileOutputStream userFile;
	String name;
	int score;
	Users player = new Users(name, score);

	public TrackingFile() {
		addUser(player);
		saveUserFile();
		
	}
	public void addUser(Users player) {
		System.out.println("add user print ts " + player.toString());
		userList.add(player);
		System.out.println(userList);
		saveUserFile();
	}
	
	public void accessFile() {
		
			userAccessFile = new Scanner("tttfile.csv");
			scanUserList();
			userAccessFile.close();
	}

	public void scanUserList() {		
		while(userAccessFile.hasNextLine()) {
			String userLine = userAccessFile.nextLine();
			String[] userLineContents = userLine.split(",");
			String userName = userLineContents[0];
			int userScore = Integer.parseInt(userLineContents[1]);
			Users user = new Users(userName, userScore);
			userList.add(user);
			saveUserFile();
		}
	}

	public void searchCurrentUser(Users player) {
		System.out.println("Search User Called");
		for(Users user : userList) {
			System.out.println("Before If");
			if(user.getFirstName().equalsIgnoreCase(player.getFirstName())) {
				score = player.getScore();
				userList.add(player);
				saveUserFile();
				
				
			} else {
				System.out.println("before Else");
				score = 0;
				System.out.println("pts" + player.toString());
				userList.add(player);
				accessFile();
				saveUserFile();
			}
		}
		System.out.println("Search User Finished");
	}
	public void saveUserFile() {
		PrintWriter userFilePW;
		try {
			userFilePW = new PrintWriter(new FileOutputStream("tttfile.csv"));
			userFilePW.println(userList);
			userFilePW.close();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public String toString() {
		return "TrackingFile []";
	}
}

