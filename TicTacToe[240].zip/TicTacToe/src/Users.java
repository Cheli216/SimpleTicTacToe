
public class Users {
	private String firstName;
	private int score;
	
	public Users(String userFirstName, int userScore) {
		this.firstName = userFirstName;
		this.score = userScore;
		getFirstName();
		setFirstName(firstName);
		getScore();
		setScore(score);
		
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String name) {
		firstName = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int setScore) {
		score = setScore;
	}

	@Override
	public String toString() {
		return firstName+ " " + "[ " + score + " ]";
	}
	
}

//public class Users{
//		private String fName;
//		private String lName;
//		private int score;
//		
//		public Users() {
//			this.fName = null;
//			this.lName = null;
//			this.score = 0;
//		}
//		
//		public Users(String fName, String lName, int score) {
//			this.fName = fName;
//			this.lName = lName;
//			this.score = score;
//		}
//
//		
//
//		public String getfName() {
//			return fName;
//		}
//
//		public void setfName(String fName) {
//			this.fName = fName;
//		}
//
//		public String getlName() {
//			return lName;
//		}
//
//		public void setlName(String lName) {
//			this.lName = lName;
//		}
//		public int getScore() {
//			return score;
//		}
//
//		public void setScore(int score) {
//			this.score = score;
//					
//		}
//
//		public boolean equals(Users otherUsers) {
//			if (otherUsers == null || (otherUsers.getClass() != getClass()))
//				return false;
//			Users users = (Users) otherUsers ;
//			
//			return this.fName.equalsIgnoreCase(users.fName);
//			
//		}
//		@Override
//		public String toString() {
//			return "User:: " + fName + " " + lName + "::"+ " Current Score: "+ score;
//		}
//
//	}
//
//	
//
